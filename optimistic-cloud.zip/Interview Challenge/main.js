class GitHub {
  constructor() {
    this.apiUrl = "https://api.github.com/users/";
  }

  async getUserDetails(username) {
    try {
      const response = await fetch(`${this.apiUrl}${username}`);
      const data = await response.json();
      this.createUserCard(data);
    } catch (error) {
      console.error("Error fetching user details:", error);
    }
  }

  createUserCard(data) {
    const main = document.querySelector("#main");
    const card = `
      <div class="card">
          <div>
              <img class="avatar" src="${data.avatar_url}" alt="${data.name}">
          </div>
          <div class="user-info">
              <h2>${data.name}</h2>
              <br/>
              <p>${data.bio}</p>
              <br/>
              <ul class="info">
                  <li><strong>Followers:</strong> ${data.followers}</li>
                  <li><strong>Following:</strong> ${data.following}</li>
                  <li><strong>Repos:</strong> ${data.public_repos}</li>
              </ul>
              <ul class="info">
                  <li><strong>Twitter:</strong> ${
                    data.twitter_username || "N/A"
                  }</li>
                  <li><strong>Location:</strong> ${data.location || "N/A"}</li>
              </ul>
          </div>
      </div>
  `;
    main.innerHTML = card;
  }
}

const searchBox = document.getElementById("search");

const gitHub = new GitHub();
gitHub.getUserDetails("example-username");

const formSubmit = () => {
  if (searchBox.value.trim() !== "") {
    gitHub.getUserDetails(searchBox.value.trim());
    searchBox.value = "";
  }
  return false;
};

searchBox.addEventListener("input", formSubmit);
